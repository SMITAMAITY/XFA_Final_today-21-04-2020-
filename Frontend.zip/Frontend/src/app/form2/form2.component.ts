import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl} from '@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-form2',
  templateUrl: './form2.component.html',
  styleUrls: ['./form2.component.css']
})
export class Form2Component implements OnInit {

   url:string= "http://localhost:8080/QuestionDetails/1";
   url1:string="http://localhost:8080/UserFeedbackDetails";
  userForm: FormGroup;
  a:any;
 userId: 4;
  result:any;
  

  constructor(private http:HttpClient,private router: Router, private formBuilder: FormBuilder) { }




  ngOnInit() {

    this.http.get(this.url).subscribe(data=>{
      this.result=data;
      console.log(this.result);
      console.log(this.result.questionDetailsId);
      this.a = this.result.answerDetails;
      console.log(this.a);
      console.log(this.a[1].answerId);
    });

  
  
  
 
   this.userForm = this.formBuilder.group({
 
   });
   console.log(this.userForm);
  }


 

  
  next():void{
    this.http.post(this.url1,this.userForm.value).subscribe(data=>{
      this.result=data;
      console.log(this.result);

    });

    this.router.navigate(['six']);

  
  }

  
  prev():void{
 
  
 
     this.router.navigate(['register']);
 
    
   }
}