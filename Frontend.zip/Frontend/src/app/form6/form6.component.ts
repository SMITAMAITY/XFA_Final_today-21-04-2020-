
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl} from '@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-form6',
  templateUrl: './form6.component.html',
  styleUrls: ['./form6.component.css']
})
export class Form6Component implements OnInit {


  // url:string= "http://localhost:8080/QuestionDetails";
  userForm: FormGroup;

  result:any;

  constructor(private http:HttpClient,private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
   this.userForm = this.formBuilder.group({
  
   });
  }

  next():void{
 

    this.router.navigate(['three']);

  
  }

  
  prev():void{
 
  
 
     this.router.navigate(['two']);
 
    
   }
  }
