import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TestregisterComponent } from './testregister/testregister.component';
import { Form1Component } from './form1/form1.component';
import { Form2Component } from './form2/form2.component';
import { Form3Component } from './form3/form3.component';
import { Form4Component } from './form4/form4.component';
import { Form5Component } from './form5/form5.component';
import { Form6Component } from './form6/form6.component';


const routes: Routes = [
  { path: 'register', component: TestregisterComponent},
  { path: '', component: Form1Component},
  { path: 'two', component: Form2Component},
  { path: 'three', component: Form3Component},
  { path: 'four', component: Form4Component},
  { path: 'five', component: Form5Component},
  { path: 'six', component: Form6Component}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
