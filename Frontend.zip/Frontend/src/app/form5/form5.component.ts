import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl} from '@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-form5',
  templateUrl: './form5.component.html',
  styleUrls: ['./form5.component.css']
})
export class Form5Component implements OnInit {

  // url:string= "http://localhost:8080/QuestionDetails";
  userForm: FormGroup;

  result:any;

  constructor(private http:HttpClient,private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
   this.userForm = this.formBuilder.group({
  
   });
  }

  next():void{
 

    this.router.navigate(['five']);

  
  }

  
  prev():void{
 
  
 
     this.router.navigate(['four']);
 
    
   }
  }
