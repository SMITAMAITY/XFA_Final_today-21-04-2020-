package com.lti.repository;

import org.springframework.data.repository.CrudRepository;

import com.lti.models.AnswerDetails;

public interface IAnswerDetailsRepository extends CrudRepository<AnswerDetails, Integer>{

}
